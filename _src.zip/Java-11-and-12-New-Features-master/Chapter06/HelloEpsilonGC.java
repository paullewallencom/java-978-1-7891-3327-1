class HelloEpsilonGC { 
    public static void main(String[] args) { 
        System.out.println("Hello to Epsilon GC!"); 
    } 
} 