class HelloZGC {
	public static void main(String[] args) {
		System.out.println("Say hello to new low pause GC - ZGC!");
	}
}
