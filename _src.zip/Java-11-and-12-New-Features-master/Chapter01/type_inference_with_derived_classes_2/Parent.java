package type_inference_with_derived_classes_2;

/**
 * @author  Mala Gupta
 */

class Parent {
    void whistle() {
        System.out.println("Parent-Whistle");
    }
}
