package type_inference_with_derived_classes;

/**
 * @author  Mala Gupta
 */

class Parent {
    void whistle() {
        System.out.println("Parent-Whistle");
    }
}