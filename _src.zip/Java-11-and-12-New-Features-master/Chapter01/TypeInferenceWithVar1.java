import java.time.LocalDateTime;
import java.util.HashMap;

/**
 * Java version required to compile and use this code: Java 10 or later.
 * @author  Mala Gupta
 */

public class TypeInferenceWithVar1 {
    public static void main(String[] args) {
        String name = "Java Everywhere";
        LocalDateTime dateTime = LocalDateTime.now();
        HashMap<Integer, String> map = new HashMap<Integer, String>();
    }
}
