package passing_inferred_variables_to_method;

/**
 * @author  Mala Gupta
 */

class Child implements MarathonRunner {
    void whistle() {
        System.out.println("Child-Whistle");
    }

    void stand() {
        System.out.println("Child-stand");
    }
}