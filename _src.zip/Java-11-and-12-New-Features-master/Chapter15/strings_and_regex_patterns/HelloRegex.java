package strings_and_regex_patterns;

public class HelloRegex {
    public static void main(String[] args) {

        // Store (\w)(\s+))[\.] in a string
        String patternToMatch = "(\\w)(\\s+)([\\.,])";      // Isn't that a lot
                                                            // to digest?
                                                            // Does the regex
                                                            // pattern has
                                                            // a single
                                                            // backslash, or,
                                                            // two of them?
    }
}
