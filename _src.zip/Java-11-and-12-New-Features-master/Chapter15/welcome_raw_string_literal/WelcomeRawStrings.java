package welcome_raw_string_literal;

/*

 */

public class WelcomeRawStrings {
    public static void main(String[] args) {
        String html =   `<HTML>
                            <BODY>
                                <H1>Meaning of life</H1>
                            </BODY>
                         </HTML> `;

    }
}
