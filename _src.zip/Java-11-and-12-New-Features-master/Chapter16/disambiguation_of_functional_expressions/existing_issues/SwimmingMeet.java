package disambiguation_of_functional_expressions.existing_issues;

class SwimmingMeet {
    static void evaluate(Swimmer swimmer) {   // code compiles

        System.out.println("evaluate swimmer");
    }

    static void evaluate(Diver diver) {      // code compiles

        System.out.println("evaluate diver");
    }
}