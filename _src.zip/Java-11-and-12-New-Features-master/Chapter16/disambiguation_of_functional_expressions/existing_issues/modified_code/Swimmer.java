package disambiguation_of_functional_expressions.existing_issues.modified_code;

interface Swimmer {                            // test METHOD IS MODIFIED
    boolean test(int lap);      // String lap changed to int lap
}