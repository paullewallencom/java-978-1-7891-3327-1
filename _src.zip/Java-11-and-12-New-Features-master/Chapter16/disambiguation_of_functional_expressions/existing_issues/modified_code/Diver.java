package disambiguation_of_functional_expressions.existing_issues.modified_code;

interface Diver {
    String dive(int height);
}