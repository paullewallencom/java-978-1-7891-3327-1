package disambiguation_of_functional_expressions.existing_issues;

interface Diver {
    String dive(int height);
}
