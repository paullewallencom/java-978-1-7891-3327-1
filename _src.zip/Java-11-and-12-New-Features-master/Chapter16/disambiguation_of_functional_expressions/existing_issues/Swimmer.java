package disambiguation_of_functional_expressions.existing_issues;


interface Swimmer {
    boolean test(String lap);
}
