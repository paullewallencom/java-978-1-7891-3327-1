package inheritance;

public class Medium extends Measurement {
    public int getLength() {
        return 9999;
    }
}
