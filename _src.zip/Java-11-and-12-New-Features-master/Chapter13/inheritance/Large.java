package inheritance;

class Large extends Measurement {}