package inheritance;

class Measurement {}