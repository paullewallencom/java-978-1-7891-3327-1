package inheritance;

public class Small extends Measurement{
    String text = "Small";
}
