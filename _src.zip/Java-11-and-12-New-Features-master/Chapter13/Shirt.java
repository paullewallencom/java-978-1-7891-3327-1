import java.awt.*;

class Shirt {
    Size size;              // instance variable of type Size
    Color color;

    Shirt(Size size, Color color) {      // Size object with Shirt instantiation
        this.size = size;
        this.color = color;
    }
}