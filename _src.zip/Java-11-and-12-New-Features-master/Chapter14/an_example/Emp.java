package an_example;

// To compile the following code download and use relevant JDK build from Oracle.com

record Emp(String name, int age) { }      // data class - one liner code