package com.ejavaguru.appcds; 
public class Wood {} 