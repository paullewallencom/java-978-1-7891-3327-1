class ConquerWorld { 
    public static void main(String args[]) { 
        System.out.println("Go and conquer the world"); 
    } 
} 