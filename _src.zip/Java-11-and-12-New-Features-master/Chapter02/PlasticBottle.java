package com.ejavaguru.appcds; 
public class PlasticBottle extends Plastic {}