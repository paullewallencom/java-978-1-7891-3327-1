import com.ejavaguru.appcds.*; 
class AppCDS { 
    public static void main(String args[]) { 
        System.out.println(new Plastic()); 
    } 
} 